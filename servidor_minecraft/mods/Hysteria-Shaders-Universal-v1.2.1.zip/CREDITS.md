# Credits

- Sixthsurge for making the awesome shaderpack Photon, which is my personal favorite and of course, the base of this shaderpack.
- Capt Tatsu for letting me base Insanity on BSL, which would later on inspire me of making Madness later on.